function openTab(tab) {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.getElementById(tab).classList.add('active');
}

function calculateEMI(type) {
    let amt = document.getElementById(type + "_amount").value;
    let rate = document.getElementById(type + "_rate").value;
    let yrs = document.getElementById(type + "_years").value;

    if(!amt || !rate || !yrs){ alert("Please fill all fields"); return; }

    amt = parseFloat(amt);
    let r = parseFloat(rate) / 12 / 100;
    let m = yrs * 12;

    let emi = (amt*r*Math.pow(1+r,m)) / (Math.pow(1+r,m)-1);
    emi = emi.toFixed(2);

    let total = (emi*m).toFixed(2);
    let interest = (total - amt).toFixed(2);

    document.getElementById(type + "_emi").innerText = emi;
    document.getElementById(type + "_total").innerText = total;
    document.getElementById(type + "_interest").innerText = interest;

    generateTable(type, amt, r, m, emi);
}

function generateTable(type, amt, r, m, emi){
    let tbody = document.querySelector("#" + type + "_table tbody");
    tbody.innerHTML = "";
    let bal = amt;

    for(let i=1;i<=m;i++){
        let interest = (bal*r).toFixed(2);
        let principal = (emi - interest).toFixed(2);
        bal = (bal - principal).toFixed(2);

        tbody.innerHTML += `
        <tr>
            <td>${i}</td>
            <td>₹${emi}</td>
            <td>₹${interest}</td>
            <td>₹${principal}</td>
            <td>₹${bal}</td>
        </tr>`;
    }
}
